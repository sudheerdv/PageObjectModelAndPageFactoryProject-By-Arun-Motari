package pfPack.tests;

import pfPack.tests.base.BaseTest;

public class LogoutTest extends BaseTest{

}
